# E-commerce Web Application
BellaCasa Home decor e-commerce website is a web-based application program. It is built using HTML, CSS and Bootstrap for designing the front end and for storing and retrieving data from database MYSQL server is used. At back-end PHP language is used.This website is beginner friendly, and has simplified website navigation, directing users where they want to go in as few clicks as possible. 
Home decor e-commerce website allows viewing various products from various categories such as furniture, kitchenware, decoration, textiles and lightings, which enables registered users to purchase desired products.
It has two login part, one is for the admin and other is for the users. This web-application provides shopping cart for customers which is safe and facile to use. If a user likes a product, he can add it to the shopping cart. Shopping cart facility is only available for the users who have an account in BellaCasa website. Payment can be done through any of three method - cash on delivery, UPI, credit/debit transaction. Once payment is successful order is placed.Administrators has the control to manage categories and products. They have collection of data of the contact list where customers have shared their queries and details.


**Providing a glimpse of the visual layout of my website**



![image](https://github.com/annu-manj/homedecor/assets/119477321/578ebde9-57a5-4d84-8c04-356af370c63f)

![image](https://github.com/annu-manj/homedecor/assets/119477321/d464cd05-19e2-4202-8775-cb0a7e61530d)

![image](https://github.com/annu-manj/homedecor/assets/119477321/c3e33367-2c2a-46c4-a59f-11ffd03e7509)

![image](https://github.com/annu-manj/homedecor/assets/119477321/1e0b9dd7-baba-4755-be0c-19090e97cc31)

![image](https://github.com/annu-manj/homedecor/assets/119477321/0562b329-5fff-49aa-aa84-ec21fb89d298)
![image](https://github.com/annu-manj/homedecor/assets/119477321/b552dad0-3af2-40bc-bd79-0dfe84d9dd4a)

![image](https://github.com/annu-manj/homedecor/assets/119477321/7ab5a9f9-1f88-497f-ac43-6883d0da36f3)
![image](https://github.com/annu-manj/homedecor/assets/119477321/915a5bdd-6db5-4bb5-a5b5-c7813ad7b39d)
![image](https://github.com/annu-manj/homedecor/assets/119477321/175493ae-bca2-4ffa-8d85-7f5a68831eb2)
![image](https://github.com/annu-manj/homedecor/assets/119477321/8220d19e-8ac8-4730-b234-594ce066c2be)
![image](https://github.com/annu-manj/homedecor/assets/119477321/2f77ba5a-02aa-4e68-b4a7-936076bc7e55)
![image](https://github.com/annu-manj/homedecor/assets/119477321/74b18480-f986-4897-80e9-1049a0196b63)

![image](https://github.com/annu-manj/homedecor/assets/119477321/b095b7a9-d7bb-4773-9d4d-c03e7b8518cc)
![image](https://github.com/annu-manj/homedecor/assets/119477321/8d70eea3-6b50-4b5d-b17b-d618c1790d37)
![image](https://github.com/annu-manj/homedecor/assets/119477321/442d1a82-0407-455e-a27d-8d7ac0ef258c)
![image](https://github.com/annu-manj/homedecor/assets/119477321/91292e0f-17c4-477a-97c1-60202a0ecb60)

![image](https://github.com/annu-manj/homedecor/assets/119477321/a2046798-6d0e-470b-933a-65e079a61eb1)
![image](https://github.com/annu-manj/homedecor/assets/119477321/7edafe9b-9755-4b37-b553-91a97f2e2e16)
![image](https://github.com/annu-manj/homedecor/assets/119477321/ea481cce-a316-45f3-99b2-cb97c8f0a547)
